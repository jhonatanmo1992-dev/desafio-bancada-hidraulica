# Desafio da Bancada Hidráulica — Pacote de publicação

## Arquivo principal
- `index.html` — jogo completo.
- `manifest.webmanifest` — permite instalação como aplicativo no celular.
- `sw.js` — cache para melhorar o funcionamento após o primeiro acesso.
- `gerar_qr.py` — gera o QR Code a partir da URL pública.

## Publicação

### Opção 1 — GitHub Pages
1. Crie um repositório no GitHub.
2. Envie `index.html`, `manifest.webmanifest` e `sw.js` para a raiz do repositório.
3. Em **Settings > Pages**, selecione a publicação pela branch principal e pasta `/root`.
4. O GitHub fornecerá uma URL semelhante a `https://SEU-USUARIO.github.io/NOME-DO-REPOSITORIO/`.
5. Use essa URL no `gerar_qr.py`.

### Opção 2 — Netlify
1. Crie uma conta no Netlify.
2. Faça o deploy da pasta deste pacote.
3. O Netlify fornecerá uma URL pública HTTPS.
4. Use essa URL no `gerar_qr.py`.

## QR Code
Depois de obter a URL pública, execute:

```bash
python gerar_qr.py "https://SUA-URL-PUBLICA/"
```

O arquivo `qr-code.png` será criado na mesma pasta.

## Teste nos celulares
- iPhone: abrir a URL no Safari.
- Android: abrir a URL no Chrome.
- Para instalar como app, usar **Adicionar à Tela de Início** quando o navegador oferecer a opção.
- O jogo não depende de banco de dados ou login.

## Importante
O QR Code só deve ser gerado depois que a URL pública definitiva estiver definida. Um QR Code com uma URL local ou de arquivo do computador não funcionará para os alunos fora desse computador.
