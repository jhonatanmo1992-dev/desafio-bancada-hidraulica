import sys
from pathlib import Path

try:
    import qrcode
except ImportError:
    print('Instale a biblioteca com: pip install qrcode[pil]')
    raise SystemExit(1)

if len(sys.argv) != 2:
    print('Uso: python gerar_qr.py "https://sua-url-publica/"')
    raise SystemExit(2)

url = sys.argv[1].strip()
if not (url.startswith('https://') or url.startswith('http://')):
    print('Informe uma URL começando com http:// ou https://')
    raise SystemExit(2)

qr = qrcode.QRCode(version=None, error_correction=qrcode.constants.ERROR_CORRECT_H, box_size=12, border=4)
qr.add_data(url)
qr.make(fit=True)
img = qr.make_image()
out = Path(__file__).with_name('qr-code.png')
img.save(out)
print(f'QR Code criado em: {out}')
